/* This file is released under the 3-clause BSD license. See COPYING-BSD. */

/**
 * @return in1 + in2
 */
double business_sum(double in, double in2);

